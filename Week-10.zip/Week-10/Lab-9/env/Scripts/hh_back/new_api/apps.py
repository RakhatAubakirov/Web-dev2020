from django.apps import AppConfig


class NewApiConfig(AppConfig):
    name = 'new_api'
